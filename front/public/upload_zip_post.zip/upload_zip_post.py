#!/usr/bin/env python3

from __future__ import annotations

import argparse
import base64
import getpass
import hashlib
import json
import os
from functools import lru_cache
from dataclasses import dataclass
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin
from urllib.request import Request, urlopen

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


DEFAULT_API_BASE_URL = "http://localhost:8082"
DEFAULT_CHUNK_SIZE_BASE64_CHARS = 1_398_104
DEFAULT_UPLOAD_SESSIONS_SECRET = "defaultUploadSessionsSecretForDevelopmentOnlyMustBeAtLeast256Bits!!"
UPLOAD_SESSION_CRYPTO_VERSION = 1
UPLOAD_SESSION_NONCE_SIZE = 12
SIDECAR_SUFFIX = ".llm-upload-session.json"

UPLOAD_SESSION_FIELD_ALIASES = {
    "archiveName": "A1",
    "fileSizeBytes": "A2",
    "chunkSizeBase64Chars": "A3",
    "totalChunks": "A4",
    "fileSha256": "A5",
    "sessionId": "A6",
    "uploadedChunks": "A7",
    "complete": "A8",
    "expiresAt": "A9",
    "chunkNumber": "A10",
    "chunkDataBase64": "A11",
}
UPLOAD_SESSION_ALIAS_FIELDS = {alias: field for field, alias in UPLOAD_SESSION_FIELD_ALIASES.items()}


@dataclass(frozen=True)
class ZipCandidate:
    path: Path

    @property
    def archive_name(self) -> str:
        return self.path.name


@dataclass(frozen=True)
class SessionMetadata:
    session_id: str
    api_base_url: str
    file_path: str
    file_size_bytes: int
    file_sha256: str
    chunk_size_base64_chars: int
    total_chunks: int


class ApiError(RuntimeError):
    pass


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="upload_zip_post.py",
        description="Upload a ZIP file in chunks and create a board post automatically.",
    )
    parser.add_argument(
        "--api-base-url",
        default=first_non_empty_env("LLM_API_BASE_URL", "NUXT_PUBLIC_API_BASE") or DEFAULT_API_BASE_URL,
        help="Backend API base URL. Defaults to LLM_API_BASE_URL, NUXT_PUBLIC_API_BASE, or http://localhost:8082.",
    )
    parser.add_argument("--token", default=first_non_empty_env("LLM_JWT_TOKEN"), help="JWT token for bearer auth.")
    parser.add_argument("--username", default=first_non_empty_env("LLM_USERNAME"), help="Admin username for login.")
    parser.add_argument("--password", default=first_non_empty_env("LLM_PASSWORD"), help="Admin password for login.")
    parser.add_argument(
        "--chunk-size-base64-chars",
        type=int,
        default=int(first_non_empty_env("LLM_UPLOAD_CHUNK_SIZE_BASE64_CHARS") or DEFAULT_CHUNK_SIZE_BASE64_CHARS),
        help="Chunk size in base64 characters. Defaults to LLM_UPLOAD_CHUNK_SIZE_BASE64_CHARS or 1398104.",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=30.0,
        help="HTTP timeout in seconds for auth/upload/finalize requests.",
    )
    args = parser.parse_args(argv)

    if args.chunk_size_base64_chars <= 0 or args.chunk_size_base64_chars % 4 != 0:
        print("오류: chunk-size-base64-chars 는 4 이상의 4의 배수여야 합니다.")
        return 1

    try:
        zip_files = discover_zip_files(Path.cwd())
        if not zip_files:
            print("현재 디렉터리에서 업로드할 ZIP 파일을 찾지 못했습니다.")
            return 1

        selected = choose_zip_file(zip_files)
        token = resolve_token(args, timeout=args.timeout)
        session = prepare_session(selected.path, args, token)

        print(f"업로드 세션: {session.session_id}")
        upload_missing_chunks(args.api_base_url, token, session, timeout=args.timeout)

        result = finalize_upload(args.api_base_url, token, session.session_id, timeout=args.timeout)
        delete_sidecar(sidecar_path(selected.path))
        print_finalize_result(result, args.api_base_url)
        return 0
    except KeyboardInterrupt:
        print("\n작업을 취소했습니다.")
        return 1
    except (ApiError, OSError, ValueError) as error:
        print(f"오류: {error}")
        return 1


def first_non_empty_env(*names: str) -> str | None:
    for name in names:
        value = os.environ.get(name)
        if value:
            return value
    return None


def discover_zip_files(directory: Path) -> list[ZipCandidate]:
    candidates: list[ZipCandidate] = []
    for path in directory.iterdir():
        if path.is_file() and path.suffix.lower() == ".zip":
            candidates.append(ZipCandidate(path=path))
    return sorted(candidates, key=lambda item: item.archive_name.lower())


def choose_zip_file(zip_files: list[ZipCandidate]) -> ZipCandidate:
    if len(zip_files) == 1:
        only = zip_files[0]
        print(f"자동 선택: {only.archive_name} ({format_bytes(only.path.stat().st_size)})")
        return only

    print("선택 가능한 ZIP 파일:")
    for index, candidate in enumerate(zip_files, start=1):
        print(f"  {index}. {candidate.archive_name} ({format_bytes(candidate.path.stat().st_size)})")

    while True:
        raw = input("업로드할 ZIP 번호를 입력하세요: ").strip()
        if raw.lower() == "q":
            raise KeyboardInterrupt

        try:
            selected_index = int(raw)
        except ValueError:
            print("번호를 입력하세요.")
            continue

        if 1 <= selected_index <= len(zip_files):
            return zip_files[selected_index - 1]

        print("목록에 있는 번호를 입력하세요.")


def format_bytes(size: int) -> str:
    if size < 1024:
        return f"{size}B"
    if size < 1024 * 1024:
        return f"{size / 1024:.1f}KB"
    if size < 1024 * 1024 * 1024:
        return f"{size / (1024 * 1024):.1f}MB"
    return f"{size / (1024 * 1024 * 1024):.1f}GB"


def resolve_token(args: argparse.Namespace, timeout: float) -> str:
    if args.token:
        return args.token

    username = args.username
    password = args.password

    if username:
        validate_ascii_credential(username, "아이디")
    if password:
        validate_ascii_credential(password, "비밀번호")

    if not username:
        username = prompt_non_empty_input("관리자 아이디: ", "아이디를 입력하세요.")
    if not password:
        password = prompt_non_empty_password("비밀번호: ", "비밀번호를 입력하세요.")

    return login(args.api_base_url, username, password, timeout=timeout)


def resolve_upload_sessions_secret() -> str:
    secret = first_non_empty_env("LLM_UPLOAD_SESSIONS_SECRET", "APP_UPLOAD_SESSIONS_SECRET")
    if secret:
        return secret
    return DEFAULT_UPLOAD_SESSIONS_SECRET


@lru_cache(maxsize=1)
def get_upload_session_key() -> bytes:
    secret = resolve_upload_sessions_secret().encode("utf-8")
    if len(secret) < 32:
        secret = hashlib.sha256(secret).digest()
    return secret[:32]


def encode_upload_session_payload(payload: dict[str, object]) -> dict[str, str]:
    encoded: dict[str, str] = {}
    for field_name, value in payload.items():
        alias = UPLOAD_SESSION_FIELD_ALIASES.get(field_name)
        if alias is None:
            raise ApiError(f"unknown upload-session field: {field_name}")
        encoded[alias] = encrypt_upload_session_value(alias, value)
    return encoded


def decode_upload_session_payload(payload: dict) -> dict[str, object]:
    decoded: dict[str, object] = {}
    for alias, encrypted_value in payload.items():
        field_name = UPLOAD_SESSION_ALIAS_FIELDS.get(alias)
        if field_name is None:
            raise ApiError(f"unknown upload-session alias: {alias}")
        if not isinstance(encrypted_value, str) or not encrypted_value:
            raise ApiError(f"{alias} must be an encrypted string")
        decoded[field_name] = decrypt_upload_session_value(alias, encrypted_value)
    return decoded


def encrypt_upload_session_value(alias: str, value: object) -> str:
    plaintext = canonical_json_text(value).encode("utf-8")
    nonce = os.urandom(UPLOAD_SESSION_NONCE_SIZE)
    ciphertext_and_tag = AESGCM(get_upload_session_key()).encrypt(
        nonce,
        plaintext,
        alias.encode("utf-8"),
    )
    envelope = bytes([UPLOAD_SESSION_CRYPTO_VERSION]) + nonce + ciphertext_and_tag
    return base64.urlsafe_b64encode(envelope).rstrip(b"=").decode("ascii")


def decrypt_upload_session_value(alias: str, encrypted_value: str) -> object:
    try:
        envelope = base64.urlsafe_b64decode(add_base64_padding(encrypted_value))
    except Exception as error:
        raise ApiError(f"{alias} must be a valid encrypted base64url string") from error

    if len(envelope) <= 1 + UPLOAD_SESSION_NONCE_SIZE:
        raise ApiError(f"{alias} encrypted payload is too short")

    version = envelope[0]
    if version != UPLOAD_SESSION_CRYPTO_VERSION:
        raise ApiError(f"{alias} encrypted payload version is not supported")

    nonce = envelope[1 : 1 + UPLOAD_SESSION_NONCE_SIZE]
    ciphertext_and_tag = envelope[1 + UPLOAD_SESSION_NONCE_SIZE :]
    try:
        plaintext = AESGCM(get_upload_session_key()).decrypt(
            nonce,
            ciphertext_and_tag,
            alias.encode("utf-8"),
        )
    except InvalidTag as error:
        raise ApiError(f"{alias} encrypted payload authentication failed") from error
    except Exception as error:
        raise ApiError(f"{alias} encrypted payload could not be decrypted") from error

    try:
        return json.loads(plaintext.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ApiError(f"{alias} encrypted payload did not decode to JSON") from error


def canonical_json_text(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def add_base64_padding(value: str) -> str:
    return value + "=" * (-len(value) % 4)


def prompt_non_empty_input(prompt: str, retry_message: str) -> str:
    while True:
        value = input(prompt).strip()
        if not value:
            print(retry_message)
            continue
        if not is_ascii_text(value):
            print("아이디는 ASCII 문자만 사용할 수 있습니다.")
            continue
        return value


def prompt_non_empty_password(prompt: str, retry_message: str) -> str:
    while True:
        value = getpass.getpass(prompt).strip()
        if not value:
            print(retry_message)
            continue
        if not is_ascii_text(value):
            print("비밀번호는 ASCII 문자만 사용할 수 있습니다.")
            continue
        return value


def validate_ascii_credential(value: str, field_name: str) -> None:
    if not is_ascii_text(value):
        raise ApiError(f"{field_name}는 ASCII 문자만 사용할 수 있습니다.")


def is_ascii_text(value: str) -> bool:
    try:
        value.encode("ascii")
    except UnicodeEncodeError:
        return False
    return True


def login(api_base_url: str, username: str, password: str, timeout: float) -> str:
    response = request_json(
        "POST",
        urljoin(normalize_api_base_url(api_base_url), "/api/v1/auth/login"),
        json_body={"username": username, "password": password},
        timeout=timeout,
    )

    token = response.get("token") if isinstance(response, dict) else None
    if not token:
        raise ApiError("login response did not include token")

    print(f"로그인 성공: {response.get('username', username)}")
    return token


def prepare_session(zip_path: Path, args: argparse.Namespace, token: str) -> SessionMetadata:
    file_path = zip_path.resolve()
    file_size_bytes = zip_path.stat().st_size
    file_sha256 = compute_sha256(zip_path)
    encoded_size_chars = encoded_base64_length(file_size_bytes)
    total_chunks = divide_and_round_up(encoded_size_chars, args.chunk_size_base64_chars)
    expected = SessionMetadata(
        session_id="",
        api_base_url=normalize_api_base_url(args.api_base_url),
        file_path=str(file_path),
        file_size_bytes=file_size_bytes,
        file_sha256=file_sha256,
        chunk_size_base64_chars=args.chunk_size_base64_chars,
        total_chunks=total_chunks,
    )
    sidecar = sidecar_path(zip_path)
    existing = load_sidecar(sidecar)
    if existing and session_matches(existing, expected):
        try:
            status = get_upload_session(args.api_base_url, token, existing.session_id, timeout=args.timeout)
            uploaded_chunks = status.get("uploadedChunks", [])
            print(f"이어올리기: 기존 세션 사용 ({len(uploaded_chunks)}/{existing.total_chunks} 청크 업로드됨)")
            return existing
        except ApiError as error:
            if not should_restart_session(str(error)):
                raise
            print(f"기존 세션을 재사용할 수 없어 새로 생성합니다: {error}")

    created = create_upload_session(
        args.api_base_url,
        token,
        zip_path.name,
        file_size_bytes,
        args.chunk_size_base64_chars,
        total_chunks,
        file_sha256,
        timeout=args.timeout,
    )
    session_id = first_present_value(created, "sessionId", "id", "session_id")
    if not session_id:
        raise ApiError("upload session response did not include sessionId")

    metadata = SessionMetadata(
        session_id=session_id,
        api_base_url=normalize_api_base_url(args.api_base_url),
        file_path=str(file_path),
        file_size_bytes=file_size_bytes,
        file_sha256=file_sha256,
        chunk_size_base64_chars=args.chunk_size_base64_chars,
        total_chunks=total_chunks,
    )
    save_sidecar(sidecar, metadata)
    return metadata


def should_restart_session(message: str) -> bool:
    return "NOT_FOUND" in message or "UPLOAD_SESSION_STATE_ERROR" in message


def compute_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as file_obj:
        while True:
            chunk = file_obj.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def divide_and_round_up(value: int, unit: int) -> int:
    return (value + unit - 1) // unit


def encoded_base64_length(file_size_bytes: int) -> int:
    return divide_and_round_up(file_size_bytes, 3) * 4


def sidecar_path(zip_path: Path) -> Path:
    return zip_path.with_name(zip_path.name + SIDECAR_SUFFIX)


def load_sidecar(path: Path) -> SessionMetadata | None:
    if not path.exists():
        return None

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        chunk_size_base64_chars = int(data["chunkSizeBase64Chars"])
        return SessionMetadata(
            session_id=data["sessionId"],
            api_base_url=normalize_api_base_url(data["apiBaseUrl"]),
            file_path=data["filePath"],
            file_size_bytes=int(data["fileSizeBytes"]),
            file_sha256=data["fileSha256"],
            chunk_size_base64_chars=chunk_size_base64_chars,
            total_chunks=int(data["totalChunks"]),
        )
    except (KeyError, TypeError, ValueError, json.JSONDecodeError):
        return None


def save_sidecar(path: Path, metadata: SessionMetadata) -> None:
    path.write_text(
        json.dumps(
            {
                "sessionId": metadata.session_id,
                "apiBaseUrl": metadata.api_base_url,
                "filePath": metadata.file_path,
                "fileSizeBytes": metadata.file_size_bytes,
                "fileSha256": metadata.file_sha256,
                "chunkSizeBase64Chars": metadata.chunk_size_base64_chars,
                "totalChunks": metadata.total_chunks,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )


def delete_sidecar(path: Path) -> None:
    try:
        path.unlink(missing_ok=True)
    except OSError:
        pass


def session_matches(existing: SessionMetadata, expected: SessionMetadata) -> bool:
    return (
        existing.api_base_url == expected.api_base_url
        and existing.file_path == expected.file_path
        and existing.file_size_bytes == expected.file_size_bytes
        and existing.file_sha256 == expected.file_sha256
        and existing.chunk_size_base64_chars == expected.chunk_size_base64_chars
        and existing.total_chunks == expected.total_chunks
    )


def create_upload_session(
    api_base_url: str,
    token: str,
    archive_name: str,
    file_size_bytes: int,
    chunk_size_base64_chars: int,
    total_chunks: int,
    file_sha256: str,
    timeout: float,
) -> dict:
    response = request_json(
        "POST",
        urljoin(normalize_api_base_url(api_base_url), "/api/v1/upload-sessions"),
        headers=auth_headers(token),
        json_body=encode_upload_session_payload({
            "archiveName": archive_name,
            "fileSizeBytes": file_size_bytes,
            "chunkSizeBase64Chars": chunk_size_base64_chars,
            "totalChunks": total_chunks,
            "fileSha256": file_sha256,
        }),
        timeout=timeout,
    )
    return decode_upload_session_payload(response)


def get_upload_session(api_base_url: str, token: str, session_id: str, timeout: float) -> dict:
    response = request_json(
        "GET",
        urljoin(normalize_api_base_url(api_base_url), f"/api/v1/upload-sessions/{session_id}"),
        headers=auth_headers(token),
        timeout=timeout,
    )
    return decode_upload_session_payload(response)


def upload_missing_chunks(api_base_url: str, token: str, session: SessionMetadata, timeout: float) -> None:
    status = get_upload_session(api_base_url, token, session.session_id, timeout=timeout)
    uploaded_chunks = {int(number) for number in status.get("uploadedChunks", [])}
    total_missing = session.total_chunks - len(uploaded_chunks)
    if total_missing <= 0:
        print("모든 청크가 이미 업로드되어 있습니다.")
        return

    zip_path = Path(session.file_path)
    raw_chunk_size_bytes = session.chunk_size_base64_chars // 4 * 3
    with zip_path.open("rb") as file_obj:
        for chunk_number in range(1, session.total_chunks + 1):
            raw_chunk = file_obj.read(raw_chunk_size_bytes)
            if not raw_chunk:
                raise ApiError(f"청크 {chunk_number} 읽기 실패: 파일이 예상보다 짧습니다.")

            if chunk_number in uploaded_chunks:
                continue

            chunk_data_base64 = base64.b64encode(raw_chunk).decode("ascii")
            if len(chunk_data_base64) > session.chunk_size_base64_chars:
                raise ApiError(
                    f"청크 {chunk_number} 인코딩 결과가 예상보다 큽니다: "
                    f"예상 최대 {session.chunk_size_base64_chars} chars, 실제 {len(chunk_data_base64)} chars"
                )

            print(f"업로드 중 ({chunk_number}/{session.total_chunks}): {zip_path.name} chunk {chunk_number}")
            response = request_json(
                "POST",
                urljoin(normalize_api_base_url(api_base_url), f"/api/v1/upload-sessions/{session.session_id}/chunks"),
                headers=auth_headers(token),
                json_body=encode_upload_session_payload({
                    "chunkNumber": chunk_number,
                    "chunkDataBase64": chunk_data_base64,
                }),
                timeout=timeout,
            )
            decode_upload_session_payload(response)


def finalize_upload(api_base_url: str, token: str, session_id: str, timeout: float) -> dict:
    return request_json(
        "POST",
        urljoin(normalize_api_base_url(api_base_url), f"/api/v1/upload-sessions/{session_id}/finalize"),
        headers=auth_headers(token),
        timeout=timeout,
    )


def print_finalize_result(result: dict, api_base_url: str) -> None:
    detail = result.get("post") if isinstance(result.get("post"), dict) else result
    post_id = detail.get("id")
    title = detail.get("title")
    body = detail.get("body")
    conversion_ready = detail.get("conversionReady")
    attachment = detail.get("attachment") or {}
    download_url = attachment.get("downloadUrl")

    print("게시글 생성 완료")
    if post_id is not None:
        print(f"- postId: {post_id}")
    if title:
        print(f"- title: {title}")
    if conversion_ready is not None:
        print(f"- conversionReady: {conversion_ready}")
    if body:
        print(f"- body: {body}")
    if download_url:
        print(f"- downloadUrl: {urljoin(normalize_api_base_url(api_base_url), download_url)}")


def normalize_api_base_url(api_base_url: str) -> str:
    return api_base_url.rstrip("/") or DEFAULT_API_BASE_URL


def auth_headers(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


def first_present_value(mapping: dict, *keys: str):
    for key in keys:
        value = mapping.get(key)
        if value not in (None, ""):
            return value
    return None


def request_json(
    method: str,
    url: str,
    *,
    headers: dict[str, str] | None = None,
    json_body: dict | None = None,
    timeout: float = 30.0,
) -> dict:
    body = None
    request_headers = {"Accept": "application/json"}
    if headers:
        request_headers.update(headers)

    if json_body is not None:
        body = json.dumps(json_body, ensure_ascii=False).encode("utf-8")
        request_headers["Content-Type"] = "application/json"

    request = Request(url, data=body, headers=request_headers, method=method)
    try:
        with urlopen(request, timeout=timeout) as response:
            return parse_json_response(response.read(), url)
    except HTTPError as error:
        raise ApiError(read_error_message(error)) from error
    except URLError as error:
        raise ApiError(f"{url} 요청 실패: {error.reason}") from error


def parse_json_response(payload: bytes, url: str) -> dict:
    if not payload:
        return {}

    try:
        decoded = payload.decode("utf-8")
    except UnicodeDecodeError as error:
        raise ApiError(f"{url} 응답이 UTF-8 JSON이 아닙니다") from error

    try:
        parsed = json.loads(decoded)
    except json.JSONDecodeError as error:
        raise ApiError(f"{url} 응답 JSON 파싱 실패: {decoded[:200]}") from error

    if not isinstance(parsed, dict):
        raise ApiError(f"{url} 응답 JSON이 객체 형식이 아닙니다")
    return parsed


def read_error_message(error: HTTPError) -> str:
    payload = error.read()
    if not payload:
        return f"{error.url} 요청 실패: HTTP {error.code}"

    try:
        decoded = payload.decode("utf-8")
        parsed = json.loads(decoded)
    except Exception:
        return f"{error.url} 요청 실패: HTTP {error.code} - {payload.decode('utf-8', errors='replace')}"

    if isinstance(parsed, dict):
        code = parsed.get("code")
        message = parsed.get("message") or parsed.get("error") or decoded
        if code:
            return f"{code}: {message}"
        return str(message)
    return decoded


if __name__ == "__main__":
    raise SystemExit(main())
