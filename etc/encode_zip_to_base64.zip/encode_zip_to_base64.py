#!/usr/bin/env python3

import base64
import ctypes
import os
import shutil
import subprocess
import sys
from pathlib import Path


WORKING_DIR = Path.cwd()
def enable_windows_vt_mode():
    if os.name != "nt":
        return True

    kernel32 = ctypes.windll.kernel32
    handle = kernel32.GetStdHandle(-11)
    if handle == 0:
        return False

    mode = ctypes.c_uint32()
    if kernel32.GetConsoleMode(handle, ctypes.byref(mode)) == 0:
        return False

    enable_vt = 0x0004
    if mode.value & enable_vt:
        return True

    return kernel32.SetConsoleMode(handle, mode.value | enable_vt) != 0


ANSI_SUPPORTED = enable_windows_vt_mode() and sys.stdout.isatty()


def list_zip_files(directory):
    return sorted(
        path for path in directory.iterdir()
        if path.is_file() and path.suffix.lower() == ".zip"
    )


def encode_file_to_base64(source_file):
    return base64.b64encode(source_file.read_bytes()).decode("utf-8")


def copy_to_clipboard(value):
    platform_name = detect_platform()

    if platform_name == "windows":
        return copy_to_windows_clipboard(value)
    if platform_name == "macos":
        return copy_to_macos_clipboard(value)
    if platform_name == "linux":
        return copy_to_linux_clipboard(value)

    return copy_with_osc52(value)


def detect_platform():
    if os.name == "nt":
        return "windows"
    if sys.platform == "darwin":
        return "macos"
    if sys.platform.startswith("linux"):
        return "linux"
    return "other"


def copy_to_windows_clipboard(value):
    commands = [
        ("clip", []),
        ("powershell", ["-NoProfile", "-Command", "Set-Clipboard -Value ([Console]::In.ReadToEnd())"]),
        ("powershell.exe", ["-NoProfile", "-Command", "Set-Clipboard -Value ([Console]::In.ReadToEnd())"]),
        ("pwsh", ["-NoProfile", "-Command", "Set-Clipboard -Value ([Console]::In.ReadToEnd())"]),
    ]
    return run_clipboard_commands(commands, value) or copy_with_osc52(value)


def copy_to_macos_clipboard(value):
    commands = [("pbcopy", [])]
    return run_clipboard_commands(commands, value) or copy_with_osc52(value)


def copy_to_linux_clipboard(value):
    commands = [
        ("wl-copy", []),
        ("xclip", ["-selection", "clipboard"]),
        ("xsel", ["--clipboard", "--input"]),
    ]
    return run_clipboard_commands(commands, value) or copy_with_osc52(value)


def run_clipboard_commands(commands, value):
    for command, args in commands:
        executable = shutil.which(command)
        if executable is None:
            continue

        if run_clipboard_command(executable, args, value):
            return True

    return False


def run_clipboard_command(executable, args, value):
    try:
        subprocess.run(
            [executable, *args],
            input=value.encode("utf-8"),
            check=True,
        )
        return True
    except (OSError, subprocess.CalledProcessError):
        return False


def copy_with_osc52(value):
    if not sys.stdout.isatty():
        return False

    payload = base64.b64encode(value.encode("utf-8")).decode("ascii")
    sys.stdout.write(f"\033]52;c;{payload}\a")
    sys.stdout.flush()
    return True


def render_selection_menu(zip_files, selected_index):
    clear_screen()
    print(f"작업 디렉터리: {WORKING_DIR}")
    print("방향키로 이동하고 Enter로 선택하세요. Esc 또는 q를 누르면 종료합니다.\n")
    print("ZIP 파일 목록")

    for index, zip_file in enumerate(zip_files):
        size_kb = zip_file.stat().st_size / 1024
        label = f" {zip_file.name} ({size_kb:.1f}KB)"
        if index == selected_index:
            print(highlight_line(label))
        else:
            print(f" {label}")

    sys.stdout.flush()


def clear_screen():
    if ANSI_SUPPORTED:
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()
        return

    os.system("cls" if os.name == "nt" else "clear")


def highlight_line(label):
    if ANSI_SUPPORTED:
        return f"\033[7m>{label}\033[0m"
    return f"> {label}"


def read_menu_key():
    if os.name == "nt":
        import msvcrt  # pylint: disable=import-error

        first = msvcrt.getch()
        if first in {b"\x00", b"\xe0"}:
            second = msvcrt.getch()
            if second == b"H":
                return "up"
            if second == b"P":
                return "down"
            return None
        if first == b"\r":
            return "enter"
        if first in {b"\x1b", b"q", b"Q"}:
            return "quit"
        return None

    try:
        import termios
        import tty
    except ImportError:
        return None

    fd = sys.stdin.fileno()
    original_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        first = sys.stdin.read(1)
        if first in {"\r", "\n"}:
            return "enter"
        if first in {"q", "Q"}:
            return "quit"
        if first == "\x1b":
            second = sys.stdin.read(1)
            if second == "[":
                third = sys.stdin.read(1)
                if third == "A":
                    return "up"
                if third == "B":
                    return "down"
            return "quit"
        return None
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, original_settings)


def prompt_selection(zip_files):
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        raise RuntimeError("방향키 선택은 터미널에서만 사용할 수 있습니다.")

    selected_index = 0
    while True:
        render_selection_menu(zip_files, selected_index)
        action = read_menu_key()
        if action == "up":
            selected_index = (selected_index - 1) % len(zip_files)
        elif action == "down":
            selected_index = (selected_index + 1) % len(zip_files)
        elif action == "enter":
            clear_screen()
            return zip_files[selected_index]
        elif action == "quit":
            raise KeyboardInterrupt


def wait_for_any_key():
    print("\n아무 키나 누르면 종료합니다.", end="", flush=True)

    if os.name == "nt":
        import msvcrt  # pylint: disable=import-error

        msvcrt.getch()
        print()
        return

    try:
        import termios
        import tty
    except ImportError:
        input()
        return

    fd = sys.stdin.fileno()
    original_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        sys.stdin.read(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, original_settings)
        print()


def main():
    zip_files = list_zip_files(WORKING_DIR)
    if not zip_files:
        print(f"'{WORKING_DIR}' 디렉터리에 ZIP 파일이 없습니다.")
        return 1

    try:
        selected_zip = prompt_selection(zip_files)
        encoded_value = encode_file_to_base64(selected_zip)
    except KeyboardInterrupt:
        print("\n작업을 취소했습니다.")
        return 1
    except RuntimeError as error:
        print(str(error))
        return 1

    if not copy_to_clipboard(encoded_value):
        print("클립보드 복사에 실패했습니다. 지원되는 클립보드 명령 또는 OSC52 지원 터미널이 필요합니다.")
        return 1

    print(f"\n{selected_zip.name} 변환 완료 및 복사되었습니다.")
    wait_for_any_key()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
